import java.io.File;
import java.io.IOException;
import java.util.Scanner;

/**
 * 
 * last name: Ngo
 * first name: Ky
 * student ID: 12088590
 * period: 4
 *
 */
public class Squeeze {
	String fname;//name of the file that contains text to be squeezed
	Scanner in;
	/**
	 * Constructor to initialize fname
	 * @param name - name of the file to be squeezed
	 */
	public Squeeze(String name)
	{
		//Your code goes here
		fname = name;
	}
	/**
	 * Method to remove and count any extra 
	 * leading spaces
	 * 
	 */
	public void squeezeText()
	{
		//Your code goes here
		String line;
		
      
         try{
            int spaces = 0;
            in = new Scanner(new File(fname));
            while (in.hasNext()){
               line = in.nextLine();
               while(line.indexOf(' ') == 0){
                  line = line.substring(1,line.length());
                  spaces++;
               }   
               while(line.indexOf(' ') == line.length()){
                  line = line.substring(0,line.length()-1);
                  spaces++;
               }
               System.out.println(spaces + " " +  line);
               spaces = 0;
            }
         }
         catch(Exception e){
            System.out.println("Error: " + fname + " (No such file or directory)");
         }
         
      }
      
     
}
