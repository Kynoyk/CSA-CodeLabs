/**
 * 
 * @author Ky ngo
 * period 4
 *
 */
public class MathFun {
	
	public void calculate () {
		
		int first = 4+9 ;
		System.out.println("4 + 9 = " + (int) first) ;
		
		int fourtySix = 46/7 ;
		System.out.println("46 / 7 = " + fourtySix);
		
		int modulus = 46%7 ;
		System.out.println("46 % 7 = " +modulus) ;
		
		double multiply = 2*3.0 ;
		System.out.println("2 * 3.0 = "+ multiply) ;
		
		double twenty = (double) 25/4 ;
		System.out.println("(double)25 / 4 = "+ (double) twenty) ;
		
		double sevenPoint = 7.75 +2 ;
		System.out.println("(int)7.75 + 2 = " +  (int)sevenPoint);
		
		int letter = 'P' ;
		System.out.println("(int)'P' = "+ (int) letter) ;
	
		char hundred= 105 ;
		System.out.println("(char)105 = " +hundred);
		
	
	}
}
