import java.util.Scanner;
/**
 * Elevator class reads takes you to the inputted floor.
 * @author Ky Ngo
 * period 4
 */
public class Elevator {
	//Your code goes here
	Scanner stdin = new Scanner(System.in);
	private int floor;
	private final int MAX_FLOORS = 20;
	
	/**
	 * This method reads in a value into floor and selects the appropriate
	 * based on the inputted value. Floor must be an int value
	 * 
 	 */
 	 
   public void simulate(){
	  System.out.print("Floor: ");
	  if (stdin.hasNextInt() == false){
	         System.out.println("Error: Not an integer");
	  }
	  else{
	     floor = stdin.nextInt();
	      
	  if (floor > 0 && floor < 13 ){
	            System.out.println("Thank you, I will take you to the actual floor " + floor);
	  }
	  else if (floor > 13 && floor <= 20){
	            System.out.println("Thank you, I will take you to the actual floor " + (floor-1));
	  }
	  else if (floor == 13){
	         System.out.println("Error: There is no thirteenth floor");
	  }
	  else if  (floor <= 0 || floor > MAX_FLOORS ){
	            System.out.println("Error: The floor must be between 1 and 20");
	  } 
	}
  }
}
