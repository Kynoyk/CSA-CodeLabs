/**
 * 
 * @author Ky ngo
 * period 4
 *
 */
public class Coins {
	private int cents;
	
	public Coins (int money) {
		cents = money ;
	}
	
	public void change () {
		int quarters = cents/25 ;
		int dimes = cents%25/10 ;
		int nickels = cents%25%10/5 ;
		int pennies = cents%25%10%5 ;
		
		System.out.println(cents + " cents =>");
		System.out.println("Quarter(s)" + "		" + quarters);
		System.out.println("Dime(s)" + "			" + dimes);
		System.out.println("Nickel(s)" + "		" + nickels);
		System.out.println("Penny(s)" + "		" + pennies);
	}
}
