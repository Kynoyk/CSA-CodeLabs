import java.util.*;
import java.io.*;
/**
 * Chapter AB23 - Two-Dimensional Arrays Exercises
 * 
 * @author Ky Ngo
 * @author Period 4
 * @author Assignment - MatrixManipulator
 */
public class MatrixManipulator
{
    /**
     * Computes the sum of all elements in a 2D array
     * @param data - data table
     * @return - returns the sum of all elements in array
     */
    public int sumOfAllArrayElements( int[][] data )
    {
        // declare the sum
        int sum = 0;
        // compute the sum
        for(int row = 0; row<data.length;row++){
           for(int col = 0; col<data[row].length; col++){
              sum += data[row][col];
           }
        }
        return sum;
    }


    /**
     * Computes the sum of each row in a 2D array
     * @param data - data table
     * @return array - returns the sum of all elements in that row in an array
     */
    public int[] sumOfEachRow( int[][] data )
    {
        // declare the row sum array
        int [] rowSums = new int[data.length];
        // compute the sums for each row
        for ( int row = 0; row < data.length; row++ )
        {
            // initialize the sum
            int sum = 0;
            // compute the sum for this row
            for(int temp = 0; temp<data[row].length;temp++){
               sum += data[row][temp];
            }
            rowSums[row] = sum;
        }
        return rowSums;
    }


    /**
     * Computes the sum of each column in a 2D array
     * @param data - data table
     * @return array- returns the sum of all elements in that column in an array
     */
    public int[] sumOfEachColumn( int[][] data )
    {
        // find the longest row
        int rowIndex = 0;
        for(int temp = 0; temp<data.length;temp++){
           if(data[temp].length > data[rowIndex].length){
              rowIndex = temp;
           }
        }
        // declare the col sum array
    	   int[] colSums = new int[data[rowIndex].length];
    	  // compute the sum of each column
         for(int col = 0; col < data[rowIndex].length; col++){
            int sum = 0;
            for(int row = 0; row<data.length;row++){
               if(data[row].length > col){
                  sum += data[row][col];
               }
            }
            colSums[col] = sum;
         }
        return colSums;
    }
    /**
     * Checks if square is magic
     * @param data - square to check if its magic or not
     * @return boolean - true if data is a magic square false otherwise
     */
    public boolean isMagic(int[][] data)
    {
    	//check if the array is a magic square. This means that it must be square, 
    	//and that all row sums, all column sums, and the two diagonal-sums 
    	//must all be equal.
    	int[] rowSums = sumOfEachRow(data);
    	int[] colSums = sumOfEachColumn(data);
    	boolean isSquare = true;
    	boolean rows = true;
      boolean cols = true;
      boolean diagonals = true;
      int diaSum1 = 0;
      int diaSum2 = 0;
      if(rowSums.length != colSums.length){
         isSquare = false;
      }
      
      if(isSquare){
         for(int a = 0; a<rowSums.length-1;a++){
              if(rowSums[a] != rowSums[a+1]){
                 rows = false;
              }
         }
         for(int b = 0; b<colSums.length-1;b++){
              if(colSums[b] != colSums[b+1]){
                 cols = false;
              }
         }
         for(int c = 0;c<data.length;c++){
            diaSum1 += data[c][c];
            diaSum2 += data[c][data.length-1-c];
            
         }
         if(diaSum1 != rowSums[0] || diaSum2 != rowSums[0]){
               diagonals = false;
            }
      }
    	if(isSquare && rows && cols && diagonals){
    	   return true;
    	}
    	return false;
    }
    /**
     * Method to find the min and max elements of the data table
     * @param data - data table
     * @return array - array with the min and max values
     */
    public int[] maxAndMinElements( int[][] data )
    {
        // declare the max and the min
        int max = data[0][0];
        int min = data[0][0];
        for(int c = 0;c<data.length;c++){
           for(int d = 0; d<data[c].length;d++){
              if(data[c][d] >max){
                 max = data[c][d];
              }
              else if(data[c][d] < min){
                 min = data[c][d];
              }
           }
        }
        
        int[] result = { max, min };
        return result;
    }


    /**
     * Finds the largest element in the matrix
     * @param data - data table
     * @return array - array withthe largest element in the table
     */
    public int[] largestElements( int[][] data )
    {
        // declare the largest in row array
        int[] largestInRow = new int[data.length];
        int largestRow;
        // find the largest element in each row
        for(int row = 0; row<data.length;row++){
           largestRow = 0;
           for(int col = 0;col<data[row].length;col++){
              if(data[row][col] > largestRow){
                 largestRow = data[row][col];
              }
              largestInRow[row] = largestRow;
           }
        }
        return largestInRow;
    }


    /**
     * Reverses all the elements in the matrix
     * @param data - data table
     */
    public void reversalOfElementsInEachRow( int[][] data )
    {
    	// reverse each row and print it
    	for(int row = 0;row<data.length;row++){
    	   int c = 0;
    	   for(int col = 0; col<data[row].length/2;col++){
    	      int temp = data[row][col];
    	      data[row][col] = data[row][data[row].length-1-c];
    	      data[row][data[row].length-1-c] = temp;
    	      c++;
    	   }
    	}
    	for(int a = 0;a<data.length;a++){
    	   for(int b = 0; b<data[a].length;b++){
    	      System.out.print(data[a][b] + " ");
    	   }
    	   System.out.println();
    	}
    }


    /**
     * Smooths the "image" by avergaing 8 neighbors
     * @param image - data table
     * @return array - array of with results of imageSmootherEasy
     */
    public int[][] imageSmootherEasy( int[][] image )
    {
        // assume a rectangular image
        int[][] smooth = new int[image.length][image[0].length];
 
        // Compute the smoothed value for
        // non-edge locations in the image.
        for(int row = 1; row<image.length-1;row++){
           for(int col = 1; col< image[row].length-1;col++){
              int temp = 0;
              if(row != 0 && row != image.length-1 || col != 0 && col != image[row].length-1){
                 temp = image[row-1][col-1] + image[row][col-1] + image[row+1][col-1];
                 temp += image[row-1][col] + image[row][col] + image[row+1][col];
                 temp += image[row-1][col+1] + image[row][col+1] + image[row+1][col+1];
              }
              smooth[row][col] = (int)temp/9;
           }
        }
        return smooth;
    }


    /**
     * Smooths the "image" by avergaing 8 neighbors including edges
     * @param image - image to be smoothed.
     * @return array - array with the smoothed image
     */
    public int[][] imageSmootherHard( int[][] image )
    {
        // assume a rectangular image
        int[][] smooth = new int[image.length+2][image[0].length+2];
        for(int i=0;i<smooth.length;i++){
            smooth[0][i]=smooth[smooth.length-1][i]=smooth[i][0]=smooth[i][smooth[0].length-1]=0;
        }
        for(int i=0;i<image.length;i++){
            for(int j=0;j<image[i].length;j++){
                smooth[i+1][j+1]=image[i][j];
            }
        }
        smooth = imageSmootherEasy(smooth);
        int [][] newArray = new int[image.length][image[0].length];
        for(int a = 0; a<newArray.length;a++){
           for(int b = 0;b< newArray[a].length;b++){
              newArray[a][b] = smooth[a+1][b+1];
           }
        }
        return newArray;
    }

}
