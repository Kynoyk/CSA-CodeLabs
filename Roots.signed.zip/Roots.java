/**
 * @author Ky ngo
 * period 4
 */

import java.util.Scanner;

public class Roots {
	Scanner stdin =new Scanner(System.in);
	private double a, b, c;
	private double num1;
	private double num2;
	private double num3;
	private double num4;
	private double num5;
	private double num6;
	private double num7;
	private double num8; 
	private double num9;
	private double root1;
	private double root2;
	private double root3;
	private double root4;
	private double root5;
	private double root6;

	/**
	 * calculate the roots of quadratic equations
	 */

	public void calculate() 
	{

		System.out.printf("%s", "Enter the coefficients a b and c for equation 1: ");
		num1 = stdin.nextDouble();
		num2 = stdin.nextDouble();
		num3 = stdin.nextDouble();
	
		System.out.printf("%s", "Enter the coefficients a b and c for equation 2: ");
		num4 = stdin.nextDouble();
		num5 = stdin.nextDouble();
		num6 = stdin.nextDouble();

		System.out.printf("%s", "Enter the coefficients a b and c for equation 3: ");
		num7 = stdin.nextDouble();
		num8 = stdin.nextDouble();
		num9 = stdin.nextDouble();
		
		root1= (((-1)*num2) + Math.sqrt(((num2*num2)-(4*num1*num3))))/(2*num1);
		root2= (((-1)*num5) + Math.sqrt(((num5*num5)-(4*num4*num6))))/(2*num4);
		root3= (((-1)*num8) + Math.sqrt(((num8*num8)-(4*num7*num9))))/(2*num7);
		root4= (((-1)*num2) - Math.sqrt(((num2*num2)-(4*num1*num3))))/(2*num1);
		root5= (((-1)*num5) - Math.sqrt(((num5*num5)-(4*num4*num6))))/(2*num4);
		root6= (((-1)*num8) - Math.sqrt(((num8*num8)-(4*num7*num9))))/(2*num7);
		
		System.out.printf("%20s %9s %9s %10s %10s", "a:" , "b:", "c:", "root1:","root2:");
		System.out.printf("%s","\n");
		System.out.printf("%10s %9.2f %9.2f %9.2f %9.2f %9.2f","#1",num1,num2,num3,root1,root4);
		System.out.printf("%s","\n");
		System.out.printf("%10s %9.2f %9.2f %9.2f %9.2f %9.2f","#2",num4,num5,num6,root2,root5);
		System.out.printf("%s","\n");
		System.out.printf("%10s %9.2f %9.2f %9.2f %9.2f %9.2f","#3",num7,num8,num9,root3,root6);
		System.out.printf("%s","\n");


	}
}