
 /**
 *
 * @author Ky Ngo
 * Period 4
 */
import java.util.*;
   /**
   * This class is driver of the CarRental class.
   */
public class CarRentalDriver {
   /**
    * This method prompts the user input.
    * @param args - the user input.
    */
	public static void main(String[] args) {
		//Your code goes here
		Scanner sc = new Scanner(System.in);
      System.out.print("Make: ");
      String maker1 = sc.nextLine();
      System.out.print("Model: ");
      String models1 = sc.nextLine();
      System.out.print("License Plate: ");
      String licenseP1 = sc.nextLine();
      CarRental car1 = new CarRental(maker1, models1, licenseP1);
      System.out.println(car1.toString());
      
      System.out.print("Make: ");
      String maker2 = sc.nextLine();
      System.out.print("Model: ");
      String models2 = sc.nextLine();
      System.out.print("License Plate: ");
      String licenseP2 = sc.nextLine();
      CarRental car2 = new CarRental(maker2, models2, licenseP2);
      System.out.println(car2.toString());
      
      System.out.print("Make: ");
      String maker3 = sc.nextLine();
      System.out.print("Model: ");
      String models3 = sc.nextLine();
      System.out.print("License Plate: ");
      String licenseP3 = sc.nextLine();
      CarRental car3 = new CarRental(maker3, models3, licenseP3);
      System.out.println(car3.toString());
      
      
	}

}