/**
 * 
 * Last name: Ngo
 * First name:Ky
 * ID: 12088590
 * Period:4
 *
 */
/** This class takes in the make, the model, and the license plate of the car
 * and computes the secret car code of the car.
 */
public class CarRental {
	//Declare instance variables here
	
	private String carCode;
	private String maker;
	private String models;
	private String licenseP;


	/**
	 * The constructor constructs the car with 3 parameters.
	 * @param make - maker of the car
	 * @param model - model of the car
	 * @param licensePlate - license plate of the car
	 */
	public CarRental(String make, String model, String licensePlate)
	{
		//Your code goes here
		maker = make;
		models = model;
		licenseP = licensePlate;
      computeCode();
	}
	/**
	 * This method computes the secret code of the car.
	 * 
	 */
	public void computeCode()
	{
		//Your code goes here
		
	int a = (int)licenseP.charAt(0);
	int b = (int)licenseP.charAt(1);
	int c = (int)licenseP.charAt(2);
	int d = ((int)licenseP.charAt(4)-48)*100;
	int e = ((int)licenseP.charAt(5)-48)*10;
	int f = ((int)licenseP.charAt(6)-48);
	int q = a+b+c+d+e+f;
	int l = q%26;
	char w = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".charAt(l);
    carCode = "" +  w + q;
      
	}
	/**
	 * This method returns the secret code of the car
	 * @return carCode - the secret code of the car
	 */
	public String getCode()
	{
		return carCode;
	}

	/**
	 * This method organizes the style of the output.
	 * @return - returns a long string (style of the output)
	 */
	public String toString()
	{
	   
		//Your code goes here
		return "Make = " + maker + "\n" + "Model = " + models + "\n" + licenseP + " = " + carCode;
	   //change this
	}

	
}
