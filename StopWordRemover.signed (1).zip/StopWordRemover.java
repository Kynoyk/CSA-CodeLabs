import java.io.File;
import java.io.FileWriter;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.io.IOException;
/**
 * 
 * Last name:
 * First name:
 * Student ID:
 * period:
 *
 */
public class StopWordRemover {
	String stopList = " a an the for of at on in to her she him his he her's and with was is ";
	String inFile, outFile;
	int maxLineLength;
	/**
	 * Initializes the input and output files and the max
	 * characters per line
	 * @param in - name of input file
	 * @param out - name of output file
	 * @param max - max characters per line (including spaces)
	 */
	public StopWordRemover(String in, String out, int max){
		//Your code goes here
		inFile = in;
		outFile = out;
		maxLineLength = max;
	}
	/**
	 * Removes the stop words and outputs the text to a file
	 * Each line of output is not more than max characters long
	 * @return the number of words removed
	 */
	public int removeStopWords(){
		//Your code goes here
		try{
		   Scanner in = new Scanner(new File(inFile));
		   FileWriter out = new FileWriter(outFile);
		   String printLine = "";
		   int counter = 0;
		   while(in.hasNext()){          // check to see if file has something
		      String word = in.next();			// next word in the input file
		      if (!stopList.contains(" " + word.toLowerCase() + " ")){   //if stop list does not contain word with spaces at the ends
		         if((printLine + " " + word).length() < maxLineLength ){ // if word + line doesn't exceed max line length
		            if(printLine.length() != 0){ // if the line is not empty
		               printLine += " " + word; // print the word with spaces
		            }
		            else{
		               printLine += word; // print the word without spaces
		            }
		         }
		         else{
		            out.write(printLine + "\n"); //if line exceed max limit, write the line
		            printLine = word;
		         }
		      }
		      else{
		         counter++; // if 
		      }
		   }
		   out.write(printLine);
		   out.close();
		   return counter;
		}
		catch(IOException e){
		   System.out.println(e);
		}
		return 0;
	}
	
}