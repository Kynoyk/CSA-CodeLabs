/**
 * 
 * @author Ky Ngo
 * Period 4
 *
 */
public class FunLoops {
	
	
	
	
	/**
	 * Method to find the first n magic squares
	 * @param n - number of magic squares to find
	 */
	public static void magicSquares(int n)
	{
		//Your code goes here
   int countSum = 0;
	int square = 0;
	int sum = 0;
	int squareCounters = 0;
	while (squareCounters <n){
	   square++;
	   while (Math.pow(square,2)> sum){
	      countSum++;
	      sum += countSum;
	   }
	   if(Math.pow(square,2)== sum){
	      System.out.print(square*square + " ");
	      squareCounters++;

	   }
	    
	}
	
		

	}
	
}
