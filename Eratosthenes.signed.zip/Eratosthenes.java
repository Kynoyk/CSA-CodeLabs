/**
 * Determines the primes less than or equal to n using the 
 * Sieve of Eratosthenes
 * @author Ky Ngo
 * period  4
 *
 */
public class Eratosthenes {
    //Your fields go here
    int[] myArray;
    int N = 0;
    int rootN = 0;
    /**
     * Constructor to initialize array of primes using the Sieve of Eratosthenes
     * @param n - all primes are less than or equal to n
     */
    public Eratosthenes (int n){
        N = n;
        rootN = (int)(Math.sqrt(n));
        myArray = new int[n];
        for (int z = 2; z <= n; z++) {
            myArray[z-2] = z;
        }
    }
    /** 
     * Count the number of primes
     * @return number of primes less than or equal to n
     */
    public int countPrimes(){
        int counter = 0;
        for (int z = 0; z <= rootN; z++){
            int currentNum = myArray[z];
            if (currentNum != 0) {
                for (int a = 2*currentNum; a <= N; a+=currentNum) {
                    myArray[a-2] = 0;
                }
            }
        }
        for (int z: myArray){
            if (z != 0) {
               counter++;
            }
        }
        return counter;
    }
    /**
	 * returns a list of primes less than or equal to n
	 * @return a list of primes less than or equal to n
	 */
    public int[] listOfPrimes(){
        int[] ans = new int[countPrimes()];
        int counter = 0;
        for (int z: myArray){
            if (z != 0){
                ans[counter] = z;
                counter++;
            }
        }
        return ans;
    }
    /**
     * @return a string containing the prime numbers and the number of prime numbers
     * in the list
     */
    public String toString(){
        String ans = " ";
        for (int z: listOfPrimes()) {
            ans += z + " ";
        }
        ans += "\n" + ("Number of primes less than or equal to " + N + " = " + countPrimes());
        return ans;
    }
}