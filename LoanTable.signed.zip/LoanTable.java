
/**
 * 
 * @author Your Name
 * Period #
 *
 */
public class LoanTable {
	//Declare your instance variables here
	private double principalAmount;
	private double numberMonth;
	private double highs;
	private double lows;

	
	/**
	 * Constructor
	 * @param principal - principal amount borrowed
	 * @param years - number of years for the loan to be paid off
	 * @param low - low interest rate
	 * @param high - high interest rate
	 */
	public LoanTable(double principal, int years, double low, double high){
		//Your code goes here
		principalAmount = principal;
		numberMonth = years*12;
		lows = low;
		highs = high;
		
		
	}
	/**
	 * Method to print the Loan table
	 */
	public void printTable(){
		//Print table heading
		
		System.out.println("Annual Interest Rate    Monthly Payment\n");
		//Your code goes here
		
		while(lows<=highs){
		   double p = principalAmount;
		   double k = (lows/100.0)/12.0;
		   double n = numberMonth;
		   double c = Math.pow((1+k),numberMonth);
		   double a = (p * k * c)/(c-1);
		   System.out.printf("%15.2f %17.2f", lows, a);
		   lows += 0.25;
		   System.out.println();
	}

}
}
