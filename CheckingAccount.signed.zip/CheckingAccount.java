/**
 * 
 * Last name: Ngo
 * First name: Ky 
 * Student ID: 12088590
 * Period #4
 */
public class CheckingAccount {
	// Your code goes here
	private double myBalance;
	private int accNum;
	
	/**
	 * Default constructor to intialize myBalance and accNum to 0;
	 */
	public CheckingAccount(){
	   myBalance = 0.0;
	   accNum = 0;
	}
	
	/**
	 * Constructor to initialize CheckingAccount to values sent in through driver 
	 * @param initialBalance - the desired initial balance for new CheckingAccount object;
	 * @param accNumb - The account number for new CheckingAccount object;
	 */
	public CheckingAccount(double initialBalance,int accNumb){
	   accNum = accNumb;
	   if(initialBalance<0){
	      throw new IllegalArgumentException("Negative balance in account " + accNum);
	   }
	   else{

	      myBalance = initialBalance;
	   }
	}
	
	/**
	 * Method to get the balance of the CheckingAccount object;
	 * @return myBalance - balance of the CheckingAccount object;
	 */
	public double getBalance(){
	   return myBalance;
	}
	
	/**
	 * Method throws an exception if amount is negative, adds amount to balance otherwise.
	 * @param amount - amount to be deposited into balance.
	 */
	public void deposit(double amount){
	   if(amount<0){
	      throw new IllegalArgumentException("Negative amount deposited in account " + accNum);
	   }
	   else{
	      myBalance+=amount;
	   }
	}
	
	/**
	 * Method throws an exception if amount withdrawn is greater than the balance, 
	 * subtracts from to balance otherwise
	 * @param amount - amount to be withdrawn from balance.
	 */
	public void withdraw(double amount){
	   if(amount>myBalance){
	      throw new IllegalArgumentException("Account " + accNum+ " overdrawn" );
	   }
	   else{
	      myBalance-=amount;
	   }
   }
}

