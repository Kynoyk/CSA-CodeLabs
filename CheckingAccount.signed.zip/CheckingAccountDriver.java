/**
 * 
 * @author Ky Ngo
 * Period #4
 */
public class CheckingAccountDriver {
   /**
    * Method that creates new Checking Account objects that purposely
    * invoke exceptions and catches them, printing the appropriate message
    * @param args - arg
    */
	public static void main(String[] args){
	   try
	   {
	      CheckingAccount acc1 = new CheckingAccount(-100.0,100);
	   }
	   catch(IllegalArgumentException e )
	   {
	      System.out.println("Negative balance in account 100");
	      try
	      {
	         CheckingAccount acc2 = new CheckingAccount(50.0,102);
	         acc2.deposit(-100);
	      }
	      catch(IllegalArgumentException f)
	      {
	         System.out.println("Negative amount deposited in account 102");
	         try
	         {
	            CheckingAccount acc3 = new CheckingAccount(50.01,103);
	            acc3.withdraw(100);
	         }
	         catch(IllegalArgumentException g)
	         {
	            System.out.println("Account 103 overdrawn");
	         }
	         
	      }
	   }
		// Your code goes here
	}
}

