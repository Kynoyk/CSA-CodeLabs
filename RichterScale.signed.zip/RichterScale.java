/**
 * 
 * @author Ky Ngo
 * period 4
 */

public class RichterScale {

 /**
  * This method compares the strength of the earthquake to the given table
  * and prints the corresponding message of the amount of damage done.
  * 
  * @param richter - Strength of the earthquake on the richter scale
  *
  */
	public static void getEffect(double richter)
	{
	   
	   if (richter < 4.5){
	      System.out.println("No destruction of buildings");
	   }
	   else if (richter >= 6.0 && richter <= 7.0){
	      System.out.println("Many buildings considerably damaged, some collapse");
	   }
		else if (richter >= 7.0 && richter < 8.0){
		   System.out.println("Many buildings destroyed");
		}
		else if (richter >= 4.5 && richter <= 6.0){
		   System.out.println("Damage to poorly constructed buildings");
		}
		else if (richter >= 8.0){
		   System.out.println("Most structures fall");
		}
	}
}
