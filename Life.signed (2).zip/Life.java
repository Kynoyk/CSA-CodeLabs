/**
 * @author Ky Ngo
 * @period 4
 */
import java.io.File;
import java.util.Scanner;

/**
 * Class to simulate bacteria life
 */
public class Life{
	private int[][] grid=new int[20][20];
	private int numberOfBacteria;
	
	/** 
	 * reads in the data from the given file and sets up the 
	 * life matrix
	 * @param fname - name of file
	 */
	public Life(String fname){
		try{
			Scanner in=new Scanner(new File(fname));
			numberOfBacteria=in.nextInt();
			while(in.hasNext()){
				grid[in.nextInt()-1][in.nextInt()-1] = 1;
			}
		}catch(Exception e){
			e.getMessage();
		}
	}
	/**
	 * method to print the life matrix
	 */
	public void printMatrix(){
		System.out.println("     12345678901234567890\n");
        for(int i=0;i<grid.length;i++){
        	System.out.printf("%-2d",i+1);
        	System.out.print("     ");
        	for(int j=0;j<grid[i].length;j++){
        		if(!isEmpty(grid,i,j))
        			System.out.print("*");
        		else
        			System.out.print(" ");
        	}
        	System.out.println();
        }
	}
	
	/**
	 * Method to count the number of neighbors of the given cell
	 * in the life matrix
	 * @param row - row number
	 * @param col - column number
	 * @return - number of neighbors of the given cell
	 */
	public int numberOfNeighbors(int row, int col){
		int[][] temp=new int[22][22];
		for(int i=0;i<grid.length;i++){
			for(int j=0;j<grid.length;j++){
				temp[i+1][j+1]=grid[i][j];
			}
		}
		row++;
		col++;
		int lifeNeighbor=temp[row-1][col-1]+temp[row-1][col]+temp[row-1][col+1]+temp[row][col-1]+temp[row][col+1]+temp[row+1][col-1]+temp[row+1][col]+temp[row+1][col+1];
		return lifeNeighbor;

	}
	/**
	 * method to determine if given cell is empty
	 * @param row - cell row number
	 * @param col - cell column number
	 * @return true if it is empty, false otherwise
	 */
	private boolean isEmpty(int[][] mat, int row, int col){
		boolean isEmpty = true;
		if(mat[row][col]==1){
			isEmpty = false;
		}
		return isEmpty;
	}
	
	/** 
	 * method that simulates the game of life
	 */
	public void generation(){
		int[][] temp=new int[20][20];
		for(int i=0;i<grid.length;i++)
			for(int j=0;j<grid[i].length;j++){
				if(!isEmpty(grid,i,j)&&(numberOfNeighbors(i,j)<2||numberOfNeighbors(i,j)>3)){
					temp[i][j]=0;
					numberOfBacteria--;
				}else if(isEmpty(grid,i,j)&&numberOfNeighbors(i,j)==3){
					temp[i][j]=1;
					numberOfBacteria++;
				}else
					temp[i][j]=grid[i][j];
			}
		grid=temp;
	}
	
	/**
	 * Method to print the statistics
	 */
	public void printStatistics(){
		int row10 = 0;
		int col10 = 0;
	    for(int a = 0;a < grid.length; a++)
	        if(grid[9][a]==1)
	            row10++;
        for(int b = 0;b<grid.length;b++)
	        if(grid[b][9]==1)
	            col10++;
        System.out.println("Number in Row 10 ---> " + row10);
        System.out.println("Number in Column 10 ---> " + col10);
        System.out.println("Number of living organisms ---> " + numberOfBacteria);
		
	}
}