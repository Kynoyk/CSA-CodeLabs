/**
 * 
 * @author Ky Ngo
 * period 4
 */
public class Car {
	//your code goes here
private int startOdometer; 
      private int currentOdometer ;
      private double gallonsConsumed;
      
      
      public Car(int a){
         startOdometer = a;
         
      }
   
      public void FillUp(int b,double c){
         currentOdometer = b;
         gallonsConsumed = c;
         
      }
   
      public double calculateMPG(){
         double MPG =(double)(currentOdometer-startOdometer)/gallonsConsumed;
         return MPG;
         
      }
   
      public void resetMPG(){
         startOdometer=currentOdometer;
         gallonsConsumed=0;
         
      }
}//end class
