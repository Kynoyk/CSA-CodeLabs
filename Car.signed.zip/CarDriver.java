/**
 * 
 * @author Ky Ngo
 * period 4
 */
import java.util.Scanner;


public class CarDriver {
	public static void main(String[] args) {
		//your code goes here
	   
	   
		Scanner stdin = new Scanner(System.in);
		
		System.out.println("MPG Lab 2017-18");
		System.out.print("New car odometer reading: ");
		int pStartOdometer = stdin.nextInt();
		Car carLab = new Car(pStartOdometer);
		
		System.out.print("Filling Station Visit: \nodometer reading: ");
		int pOdometerReading = stdin.nextInt();
		System.out.print("gallons to fill tank: ");
		double pGallonsToFill = stdin.nextDouble();
		carLab.FillUp(pOdometerReading, pGallonsToFill);
		System.out.println();
		System.out.printf("%s %.2f %s %s" ,"Miles per gallon:  ", carLab.calculateMPG(),"\n","\n" );
	   
	   
	   carLab.resetMPG();
		System.out.println("Filling Station Visit:");
		System.out.print("odometer reading: ");
		pOdometerReading = stdin.nextInt();
		System.out.print("gallons to fill tank: " );
		pGallonsToFill = stdin.nextDouble();
		System.out.println();
		carLab.FillUp(pOdometerReading, pGallonsToFill);
		System.out.printf("%s %.2f" ,"Miles per gallon:  ", carLab.calculateMPG());
		

		
	}

}
