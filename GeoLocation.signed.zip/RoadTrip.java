import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
/**
 * 
 * @author your name
 * period #
 *
 */
public class RoadTrip
{
   ArrayList <GeoLocation> listOfLocations = new ArrayList <GeoLocation>();
    //list of geo locations
    //your code goes here
    
    /**
     * Constructor reads in the geo locations from the given file and adds them to 
     * the list
     * @param fname - file name
     */
    public RoadTrip(String fname)
    {
    	//your code goes here
    	try{
    	   Scanner in = new Scanner(new File(fname));
    	   while(in.hasNext()){
    	      addStop(in.next(),in.nextDouble(),in.nextDouble());
    	   }
    	}
    	catch(Exception e){
    	   System.out.print(e.getMessage());
    	}
    }
    /**
     * Create a GeoLocation and add it to the road trip
     * @param name - name of the geo location
     * @param latitude - latitude in degrees
     * @param longitude - longitude in degrees
     */
   
    public void addStop(String name, double latitude, double longitude)
    {
        GeoLocation g1 = new GeoLocation(name,latitude,longitude);
        listOfLocations.add(g1);
    }

    /**
     * Get the total number of stops in the trip
     * @return total number of stops
     */
    public int getNumberOfStops()
    {
        //your code goes here
        return listOfLocations.size();
    }

    /**
     * Get the total miles of the trip
     * @return the total miles
     */
    
    public double getTripLength()
    {
        //your code goes here
        double tripLength = 0;
        for(int index = 0; index<listOfLocations.size()-1;index++){
           GeoLocation first = listOfLocations.get(index);
           GeoLocation second = listOfLocations.get(index+1);
           tripLength += first.distanceFrom(second);
         }
         return tripLength;
      }
        
    

    /**
     * Return a formatted toString of the trip
     * @return information about the trip
     */
     
    public String toString()
    {
        //your code goes here
        String str = " ";
        for(int i = 0; i < listOfLocations.size();i++){
           str += listOfLocations.get(i).toString();
           str += "\n";
        }
        str += "Stops: " + getNumberOfStops();
        str += "\nTotal miles: " + getTripLength()+" miles\n";
        return str;
    }
}