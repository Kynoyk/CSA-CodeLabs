 /**
 * 
 * @author Ky ngo
 * period 4
 *
 */
public class RoachPopulation {
	private int population =10; // roach population

	
	public RoachPopulation(int init){
	
	}
	
	public void breed(){
		population *=2 ;
	}
	
	public void spray(){
		population = population - (int)(population*0.1);
	}
	
	public int getRoaches(){
		return (int) population;
	}
}
