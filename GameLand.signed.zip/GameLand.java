
import java.util.*; 
/**
 * 
 * @author Ky Ngo
 * Period 4
 */
 
public class GameLand { 
	//Declare Random object here
    Random chooser = new Random();
	//Declare other instance variables here
	private int roll = 0;
	private int square1 = 0;
	private int square2 = 0;
    
    /**
     * Method to create a new Random object and
     * initialize with the give seed
     * @param seed - seed for the random number generator
     */
    public GameLand(int seed)
    {
    	//Your code goes here
    	chooser = new Random(seed);
    }
    /**
     * Method that simulates the roll of two dice
     */
    public void roll() 
    { 
    	//Your code goes here
      roll = chooser.nextInt(6)+chooser.nextInt(6)+2;
    } 
 
        /** Method that runs the game. For each move
     *  print the roll and the players location after the move
     * 
     */
    public void moving() {
    	//Your code goes here
    	while (square1 <= 100 && square2 <= 100){ 
    	   if (square1<=100 && square2 <= 100){
    	      roll();
    	      System.out.printf("%s %d %s", "Player A rolled a ", roll , ">>> ");
    	      square1 += roll;
    	      if (roll == 2 || roll == 12){
    	         square1 -= 2;
    	         System.out.printf("%s %d %s","** Player A is now at ",square1, "\n");
    	      }
    	      else if (square1 == square2){
    	         System.out.print("- BUMPED - ");
               square2 = 0;
               System.out.printf("%s %d %s"," Player A is now at ",square1, "\n");
         	}
    	      else if (roll != 7 && square1 <= 100 ){
    	         System.out.printf("%s %d %s", "Player A is now at ", square1, "\n");
    	      }
    	      else if (roll == 7 ){
    	         square1 -=14;
    	         if(square1 <0){
    	            square1 = 0;
    	         }
    	         System.out.printf("%s %d %s","******* Player A is now at ",square1, "\n");
    	      }
    	      else if (square1 >= 100){
    	         System.out.printf("%s %s","Player A WINS!!", "\n");
    	         System.out.println("Player A is now at " + square1);
    	         System.out.println("Player B is now at " + square2);
    	         
    	      }
    	      else{
    	       square1 += roll;  
    	      }
            
      	} 
      	
      	
    	   if (square2<=100 && square1 < 100){
    	      roll();
    	      System.out.printf("%s %d %s", "Player B rolled a ", roll , ">>> ");
    	      square2 += roll;
    	      if(roll == 2){
    	         square2 -= 2;
    	         System.out.printf("%s %d %s","** Player B is now at ",square2, "\n");
    	      }
    	      else if (roll == 12){
    	         square2 -= 12;
    	         System.out.printf("%s %d %s","** Player B is now at ",square2, "\n");
    	      }
    	      else if (square1 == square2){
    	         System.out.print("- Bumped -");
    	         square1 = 0;
    	         System.out.printf("%s %d %s"," Player B is now at ",square2, "\n");
    	      }
    	      else if (roll != 7 && square2 <=100 ){
    	         System.out.printf("%s %d %s", "Player B is now at ", square2, "\n");
    	      }
    	      else if (roll == 7 ){
    	         square2 -= 14;
    	         if (square2 < 0){
    	            square2 = 0;
    	         }
    	         System.out.printf("%s %d %s","******* Player B is now at ",square2, "\n");
    	      }
    	      else if (square2 >= 100){
    	         System.out.printf("%s %s","Player B WINS!!", "\n");
    	         System.out.println("Player A is now at " + square1);
    	         System.out.println("Player B is now at " + square2);
    	        
    	      }
    	      else{
    	       square2 += roll;  
    	      }
    	      
    	      if (square1 == square2){
            square2 =0;
         	}
            
      	} 
      	
    	}
    	 
    }      
}
