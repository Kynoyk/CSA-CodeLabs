import java.util.Scanner;
/**
 * This class takes in an amount and encodes it with the appropriate asteriks.
 **/
public class CheckProtection {
	
	private String amount;
	private final int MAX_LENGTH;
	

	/**
	 * Constructor prompts For the amount, rounds the amount to two
	 * decimal places checks if the amount entered has a length less than
	 * MAX_LENGTH If the amount exceeds the MAX_LENGTH, prints an error message
	 * If the amount is within range prints the check amount with commas and
	 * spaces filled with *
	 * @param max - the max length of the amount string
	 */
public CheckProtection(int max) 
	{
		MAX_LENGTH = max;
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the check amount: ");
		double checkAmount = sc.nextDouble()*100.;
		amount = "" + (Math.round(checkAmount)/100.);
		if (amount.charAt(amount.length()-1)=='0'){
		   amount += '0';
		}
		amount = addCommas(amount.substring(0,amount.length()-3))+amount.substring(amount.length()-3);
		if(amount.length()>MAX_LENGTH){
		   System.out.println("Error: Number is too big");
		}
		else{
		   amount = addAsterisks(amount);
		   printAmount();
		}

	}


	/**
	 * Adds commas to the number recursively
	 * 
	 * @param s - number as a string
	 * @return - number with commas inserted
	 */
	public String addCommas(String s) 
	{
		//Your code goes here
		if(s.length()<=3){
		   return s;
		}
		return addCommas(s.substring(0,s.length()-3))+","+s.substring(s.length()-3);

	}

	/**
	 * Adds the stars to fill in leading spaces recursively
	 * 
	 * @param s - number as a string
	 * @return - number with leading stars
	 */
	public String addAsterisks(String s) 
	{
		//Your code goes here
		if(s.length() >= MAX_LENGTH){
		   return s;
		}
		return addAsterisks("*"+s);
	}

	/**
	 * Prints the amount with leading stars and commas in the between
	 */
	public void printAmount() 
	{
		//Your code goes here
		 System.out.println("amount = $"+ amount);
	}
}
