/**
 * @Name Ky Ngo
 * period 4
 */
import java.io.File;
import java.util.Scanner;

/**
 * Class to find the secret message
 */
public class SecretMessage {
	private char[][] message;
	private char[][] cover;
	private final int maxColumns = 80;
	private int startRow;
	private int startCol;
	//Do not add any other instance variables
	/**
	 * Constructor to read the plain text messages and the cover 
	 * messages from the given file.
	 * Calls getSecretMessage to reveal the secret message from under
	 * the cover. Then prints the secret message 
	 * @param fname - file name
	 */
	public SecretMessage(String fname){
		//Your code goes here
		try{
		   Scanner in = new Scanner(new File(fname));
		   int first = in.nextInt();
		   while (first >0){
		      int lines = in.nextInt();
            in.nextLine();
		      message = new char[lines][maxColumns];
		      for (int a = 0; a < lines; a++){
		         String lineTemp = in.nextLine();
		         for (int b = 0; b < lineTemp.length(); b++){
		            message[a][b] = lineTemp.charAt(b);
		         }
		      } 
		      startRow = in.nextInt();
		      startCol = in.nextInt();

		      int numberOfLines = in.nextInt();
		      cover = new char[numberOfLines+1][maxColumns];
		      for (int a = 0; a <= numberOfLines; a++){
		         String lineTemp2 = in.nextLine();
		         for (int b = 0; b < lineTemp2.length(); b++){
		            cover[a][b] = lineTemp2.charAt(b);
		         }
		      }
		      System.out.println(getSecretMessage());
		      first--;
		   } 
		}catch(Exception e){
		   System.out.println(e.getMessage());
		}
	}
	
	/**
	 * Method that extracts the secret message from under the cover
	 * cover is placed at startRow and startCol. If the element in cover
	 * is 'O', the corresponding letter in the message is extracted
	 * @return the secret message
	 */
	public String getSecretMessage(){
		//Your code goes here
		String secretMessage = "";
	   
	   for(int a = 0; a < cover.length; a++){
	      for(int b = 0; b < cover[a].length;b++){
	         if(cover[a][b] == 'O'){
	            secretMessage += message[a+startRow-1][b+startCol];

	         }
	      }
	   }
		return secretMessage;
	}
}
