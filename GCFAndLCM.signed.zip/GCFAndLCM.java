/**
 * 
 /**
 * 
 * @author Ky Ngo
 * Period 4
 *
 */
public class GCFAndLCM {
	/**
	 * Method to find the greatest common divisor
	 * of the given numbers
	 * @param a - first number
	 * @param b - second number
	 * @return - the greatest common divisor
	 */
	public static int GCF(int a, int b) {
		int n = Math.max(a,b);
		while (1 == 1){
		   if(a%n == 0 && b%n == 0){
		      return n;
		   }
		
		   else {		  
		   n--;
		   }
	   }
	}	
		//Your code goes here
		 

	
	/**
	 * Method to find the least common multiple of the 
	 * given numbers
	 * @param a - first number
	 * @param b - second number
	 * @return - the least common multiple
	 */
	public static int LCM(int a, int b){
		//Your code goes here
		int n = 1;
		while (1 == 1){
		   if (n%a == 0 && n%b == 0){
		      return n;
		   }
		   else {
		      n++;
		   }
		
		  }
	}
}

