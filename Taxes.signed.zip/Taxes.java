
/**
 * Taxes class - class used to calculate the federal, social security and state taxes
 * @author Ky Ngo Period 4
 */
public class Taxes {
	//declare instance variable
	//Your code goes here
   private double hoursWorked;
   private double hourRate;
	//declare constants
	//Your code goes here
   private final double FEDERAL_TAX_RATE = 0.15;
   private final double FICA_RATE = 0.0765;
   private final double STATE_TAX_RATE = 0.04;

	/**
	 * Constructor with specified work hours and hour rate.
	 * @param hours - the hours worked
	 * @param rate - the rate of pay per hour.
	 */
	public Taxes(double hours, double rate)
	{
		//Your code goes here
      hoursWorked = hours;
      hourRate = rate;
	}// end constructor
	
	/**
	 * Accessor method that gets the total hours worked and returns it.
	 * @return hoursWorked - How many hours one works.
	 */
	public double getHoursWorked()
	{
		//Your code goes here
      return hoursWorked;
	}// end method
		
	/**
	 * Accessor method that gets the rate of pay per hour(salary) and returns it.
	 * @return hourRate - How much one earns per hour.
	 */
	public double getHourlyRate()
	{
      return hourRate;
		//Your code goes here

	}// end method
		
	/**
	 * Accessor method that gets the federal tax rate and returns it.
	 * @return FEDERAL_TAX_RATE - The rate for federal tax.
	 */
	public double getFedTaxRate()
	{
      return FEDERAL_TAX_RATE;
		//Your code goes here

	}// end method
		
	/**
	 * Accessor method that gets the Social security rate and returns it.
	 * @return FICA_RATE - The rate for FICA tax.
	 */
	public double getSocSecurityRate()
	{
      return FICA_RATE;
		//Your code goes here

	}// end method
		
	/**
	 * Accessor method that gets the state tax rate and returns it.
	 * @return STATE_TAX_RATE - The rate for state tax.
	 */
	public double getStateTaxRate()
	{
		//Your code goes here
		 return STATE_TAX_RATE;
	}// end method
	
	/**
	 * Method that computes Gross Pay and returns it.
	 * @return Returns Gross Pay.
	 */
	public double computeGrossPay()
	{
		//Your code goes here
      return hourRate*hoursWorked;
	}// end method
	
	/**
	 * Method that computes Federal Taxes and returns it.
	 * @return returns Federal Tax
	 */
	public double computeFedTax()
	{
      //Your code goes here
      return (hourRate*hoursWorked)*FEDERAL_TAX_RATE;
	}//end method
	/**
	 * Method that computes Social Security Tax and returns it. 
	 * @return Returns Social Security Tax.
	 */
	public double computeSocSecurity()
	{

		//Your code goes here
      return (hourRate*hoursWorked)*FICA_RATE;
	}//end method
	
	/**
	 * Method that computes State Tax and returns it.
	 * @return Returns Social Security Tax.
	 */
	public double computeStateTax()
	{
		//Your code goes here
      return (hourRate*hoursWorked)*STATE_TAX_RATE;
	}//end method
	/**
	 * Method that computes Total tax.
	 * @return Returns Total Tax.
	 */
	private double computeTotalTax()
	{
      return computeStateTax() + computeSocSecurity() + computeFedTax();
		//Your code goes here

	}//end method
	/**
	 * Method that computes Net Pay and returns it.
	 * @return Returns Net Pay.
	 */
	public double computeNetPay()
	{
		//Your code goes here
		return computeGrossPay()-(computeStateTax() + 
				computeSocSecurity() + computeFedTax());
	}//end method
	
}
